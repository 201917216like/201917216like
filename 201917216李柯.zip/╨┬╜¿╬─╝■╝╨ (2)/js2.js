
function submit()
{alert("�ύ�ɹ�");
window.location.reload();
}
